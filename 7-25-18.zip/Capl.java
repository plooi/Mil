import java.util.ArrayList;
import static ljs.Obj.*;
import ljs.Obj;
import java.io.*;
//add the -- comments
//Cool Awesome Programming Language
//Minimal-Architecture Programming Language
//Minimal Infrastructure Language
public class Capl
{
    public static final int TOKEN_TYPE_IDENTIFIER = 1;
    public static final int TOKEN_TYPE_PUNC = 2;
    public static final int TOKEN_TYPE_INDENT = 3;
    public static final int TOKEN_TYPE_COMMENT = 4;
    public static final int TOKEN_TYPE_INTEGER_LITERAL = 5;
    public static final int TOKEN_TYPE_DOUBLE_LITERAL = 5;
    public static final int TOKEN_TYPE_STRING_LITERAL = 5;
    public static void main(String[] args)
    {
        require(args.length >= 1, "In order to run Capl, you must execute the command \"capl myprogram.ca\" where \"myprogram.ca\" is replaced with the existing Capl (.ca) file that you would like to run.");
        
        File toRun = new File(new File(args[0]).getAbsolutePath());
        require(toRun.isFile(), "The first argument received, which was \"" + args[0] + "\" is not a file. The thing is, Capl will only work if the first argument is a valid, Capl file. Note that a directory is not a valid file. Note that a Capl file is a file that has the file extension of \".ca\".");
        
        File topDirectoryFile = toRun.getParentFile();
        
        
        Directory topDirectory = loadDirectory(topDirectoryFile, null);
        
        loadAllFunctionModifiers(topDirectory);
        
        p((topDirectory).toString());
        //run(topDirectory);
    }
    public static void run(Directory topDirectory, File mainFile)
    {
        CodeFile mainCodeFile = null;
        for(CodeFile cf : topDirectory.files)
            if(cf.myFile.equals(mainFile))
            {
                mainCodeFile = cf;
                break;
            }
        require(mainCodeFile != null, "There does not exist a loaded file in the directory \"" + topDirectory.myFile.getName() + " that is the main file, which is \"" + mainFile.getName() + "\".")
        require(mainCodeFile.functionLocations.keySet().contains("main"), "Execution failed because the file which you tried to execute, \"" + mainCodeFile.myFile.getName() + "\" does not have a main function. In order to start your program, you need to add a function with the name of 'main' to the file which you want to directly execute.")
        
        evaluate(mainCodeFile, "main()", 0, tokenize("main()"))
    }
    
    
    /*
    The destination parameter is an object that the return value of this method will be placed in.
    Since this method is a void method, the only way to get a return value is through passing in
    the destination object, and then running this method and then the destination object will 
    magically have its values changed.
    destination.a is the return value. Simple enough
    destination.b is the index at which the next token after the evaluated expression starts at
    
    methods to implement
        boolean isEqual(int start, int end, String body, String compare)
        Object executeMethod(String methodName, CodeFile locationOfExecution, ArrayList<Object> params)
        
    */
    public static void evaluate(CodeFile locationOfExecution, String text, int tokenIndexToExecute, ArrayList<Integer> tokenization, Tuple<Object, Integer> destination)
    {
        int currentTokenStart = tokenization[tokenIndexToExecute];
        int currentTokenEnd = tokenization[tokenIndexToExecute + 1];
        
        if(isEqual(currentTokenStart, currentTokenEnd, text, "if"))
        {
            
        }
        else if(isEqual(currentTokenStart, currentTokenEnd, text, "for"))
        {
            
            
        }
        else if(isEqual(currentTokenStart, currentTokenEnd, text, "while"))
        {
        
        }
        else if(isEqual(currentTokenStart, currentTokenEnd, text, "try"))
        {
        
        }
        else if(isEqual(currentTokenStart, currentTokenEnd, text, "onfail"))
        {
        
        }
        else //it's an identifier
        {
            boolean existsNextToken = tokenIndexToExecute + 2 < tokenization.length();
            
            if(existsNextToken)
            {
                int nextTokenStart = tokenization.get(tokenIndexToExecute + 2);
                int nextTokenEnd = tokenization(tokenIndexToExecute + 3);
                
                if(isEqual(nextTokenStart, nextTokenEnd, text, "="))//assignment operator
                {
                    
                }
                else if(isEqual(nextTokenStart, nextTokenEnd, text, "("))//function call
                {
                    ArrayList<Object> functionInputs = new ArrayList<>();
                    int tokenIndex = tokenIndexToExecute + 4;//tokenIndexToExecute + 4 is the first index inside the function call
                    
                    String functionName = text.substring(tokenization.get(currentTokenStart), tokenization.get(currentTokenEnd));
                    
                    while(true)
                    {
                        int tokenStart = tokenization.get(tokenIndex);
                        int tokenEnd = tokenization.get(tokenIndex + 1);
                        
                        if(isEqual(tokenStart, tokenEnd, text, ")"))
                        {
                            Object returnValue = executeMethod(functionName, locationOfExecution, functionInputs);
                            destination.a = returnValue;
                            destination.b = tokenIndex + 2;
                            return;
                        }
                        else if(isEqual(tokenStart, tokenEnd, text, ","))
                        {
                            tokenIndex += 2;
                        }
                        else //it's a normal function input. Evaluate it and then pass it in
                        {
                            evaluate(locationOfExecution, text, tokenIndex, tokenization, destination);
                            tokenIndex = destination.b;
                            functionInputs.add(destination.a);
                        }
                    }
                    
                    
                    
                    
                }
                else if(getTokenTypeNoErr(tokenIndexToExecute, tokenization, text) == TOKEN_TYPE_INTEGER_LITERAL)
                {
                    
                }
                else if(getTokenTypeNoErr(tokenIndexToExecute, tokenization, text) == TOKEN_TYPE_DOUBLE_LITERAL)
                {
                    
                }
                else if(getTokenTypeNoErr(tokenIndexToExecute, tokenization, text) == TOKEN_TYPE_STRING_LITERAL)
                {
                    
                }
                else//it is a variable value get
                {
                    
                }
            }
            
        
        }
        throw new RuntimeException("Tried to execute code but could not recognize pattern. This error should have been caught by the syntax checker");
        
    }
    public static void executeMethod(String functionName, CodeFile locationOfExecution, ArrayList<Object> functionInputs)
    {
        
    }
    public static boolean isEqual(int start, int end, String text, String compare)
    {
        int len = end - start;
        for(int i = 0; i < len; i++)
        {
            if(compare[i] != text[i + start])
                return false;
        }
        return true;
    }
    
    /*
    This uses breadth-first search
    */
    @SuppressWarnings("unchecked")
    public static CodeFile findCodeFileOfName(Directory startSearch, String nameOfFile)
    {
        for(CodeFile f : startSearch.files)
        {
            if(f.myFile.getName().equals(nameOfFile))
            {
                return f;
            }
        }
        ArrayList<Directory> subdirs = (ArrayList<Directory>)startSearch.subdirs.clone();
        
        
        while(true)
        {
            for(Directory subdir : subdirs)
            {
                for(CodeFile f : subdir.files)
                {
                    if(f.myFile.getName().equals(nameOfFile))
                    {
                        return f;
                    }
                }
            }
            ArrayList<Directory> newSubdirs = new ArrayList<>();
            for(Directory subdir : subdirs)
            {
                for(Directory subSubdir : subdir.subdirs)
                {
                    newSubdirs.add(subSubdir);
                }
            }
            subdirs = newSubdirs;
            if(subdirs.isEmpty())
                return null;
        }
    }
    public static Directory loadDirectory(File file, Directory parentOfThisDirectory)
    {
        Directory ret = new Directory();
        ret.parent = parentOfThisDirectory;
        ret.myFile = file;
        for(File subdir : file.listFiles())
        {
            if(subdir.isFile() && (subdir.getName().endsWith(".ca") || subdir.getName().endsWith(".capl")))
                ret.files.add(initCodeFile(subdir, ret));
            else if(subdir.isDirectory())
                ret.subdirs.add(loadDirectory(subdir, ret));    
        }
        return ret;
    }
    public static CodeFile initCodeFile(File file, Directory parent)
    {
        
        CodeFile ret = new CodeFile();
        ret.text = '\n' + efficientLoadFile(file.getAbsolutePath());//adding '\n' allows the tokenizer to account for an indent of the first line
        ret.myFile = file;
        ret.parent = parent;
        
        ret.tokenization = tokenize(ret.text);
        
        findMethods(ret);
            
        
        //do the tokenization and function finding here
        return ret;
    }
    public static void loadAllFunctionModifiers(Directory dir)
    {
        ArrayList<Integer> tokenTypePattern = arrayList("int or double", TOKEN_TYPE_WORDNUM, TOKEN_TYPE_WORDNUM, TOKEN_TYPE_PUNC);
        for(CodeFile cf : dir.files)
        {
            
            int tokenizationLength = cf.tokenization.size();
            for(int i = 0; i < tokenizationLength; i += 2)
            {
                boolean foundMatch = true;
                for(int j = 0; j < tokenTypePattern.size(); j++)
                {
                    int thisTokenIndex = i + j*2;
                    boolean matches;
                    if(j == 0)
                        matches = getTokenTypeNoErr(thisTokenIndex, cf.tokenization, cf.text) == TOKEN_TYPE_INTEGER_LITERAL || getTokenTypeNoErr(thisTokenIndex, cf.tokenization, cf.text) == TOKEN_TYPE_DOUBLE_LITERAL;
                    else
                        matches = getTokenTypeNoErr(thisTokenIndex, cf.tokenization, cf.text) == tokenTypePattern.get(j);
                    if(j == 1)
                        matches = matches && (portionEquals(thisTokenIndex, cf.tokenization, cf.text, "before") || portionEquals(thisTokenIndex, cf.tokenization, cf.text, "after"));
                    if(j == 3)
                        matches = matches && cf.text.charAt(cf.tokenization.get(thisTokenIndex)) == '(' && cf.tokenization.get(thisTokenIndex)+1 == cf.tokenization.get(thisTokenIndex + 1);
                    if(! matches)
                    {
                        foundMatch = false;
                        break;
                    }
                }
                if(foundMatch)
                {
                    
                    int startTokenIndexOfMethodName = i + 4;
                    int endTokenIndexOfMethodName = i + 5;
                    String functionName = cf.text.substring(cf.tokenization.get(startTokenIndexOfMethodName), cf.tokenization.get(endTokenIndexOfMethodName));
                    String orderAsString = cf.text.substring(cf.tokenization.get(i), cf.tokenization.get(i + 1));
                    
                    FunctionModifier fm = new FunctionModifier();
                    fm.fileOfOrigin = cf;
                    fm.location = i;
                    fm.order = Double.parseDouble(orderAsString);
                    fm.tfBeforeAfter = portionEquals(i+2, cf.tokenization, cf.text, "before");
                    
                    
                    if(cf.functionFiles.keySet().contains(functionName))
                    {
                        //okay good we know where it is
                    }
                    else
                    {
                        Tuple<CodeFile, Integer> searchResult = searchForFunction(cf, functionName);
                        if(searchResult == null)
                        {
                            throw new RuntimeException("Tried to search for function " + functionName + " from " + cf.myFile.getName() + " and no function was found.");
                        }
                        cf.functionFiles.put(functionName, searchResult.a);
                    }
                    CodeFile ownerOfFunction = cf.functionFiles.get(functionName);
                        
                        
                    if(fm.tfBeforeAfter == true)//before
                    {
                        if(ownerOfFunction.functionBeforeModifiers.get(functionName) == null)
                            ownerOfFunction.functionBeforeModifiers.put(functionName, new ArrayList<>());
                        ArrayList<FunctionModifier> functionBeforeModifiers = ownerOfFunction.functionBeforeModifiers.get(functionName);
                        int j = 0;
                        while(j < functionBeforeModifiers.size())
                        {
                            if(functionBeforeModifiers.get(j).order > fm.order){/*okay keep going*/}
                            else
                            {
                                break;
                            }
                            j++;
                        }
                        functionBeforeModifiers.add(j, fm);
                    }
                    else//after
                    {
                        if(ownerOfFunction.functionAfterModifiers.get(functionName) == null)
                            ownerOfFunction.functionAfterModifiers.put(functionName, new ArrayList<>());
                        ArrayList<FunctionModifier> functionAfterModifiers = ownerOfFunction.functionAfterModifiers.get(functionName);
                        int j = 0;
                        while(j < functionAfterModifiers.size())
                        {
                            if(functionAfterModifiers.get(j).order < fm.order){/*okay keep going*/}
                            else
                            {
                                break;
                            }
                            j++;
                        }
                        functionAfterModifiers.add(j, fm);
                    }
                }
                
            }
        }
        for(Directory subdir : dir.subdirs)
        {
            loadAllFunctionModifiers(subdir);
        }
    }
    public static void findMethods(CodeFile cf)
    {
        int tokenizationLength = cf.tokenization.size();
        
        ArrayList<Integer> tokenTypePattern = arrayList(TOKEN_TYPE_INDENT, TOKEN_TYPE_WORDNUM, TOKEN_TYPE_PUNC);
        
        for(int i = 0; i < tokenizationLength; i += 2)
        {
            boolean foundMatch = true;
            for(int j = 0; j < tokenTypePattern.size(); j++)
            {
                int thisTokenIndex = i + j*2;
                boolean matches = getTokenTypeNoErr(thisTokenIndex, cf.tokenization, cf.text) == tokenTypePattern.get(j);
                if(j == 0)
                    matches = matches && (getIndent(thisTokenIndex, cf.tokenization, cf.text) == 0);
                if(j == 2)
                    matches = matches && cf.text.charAt(cf.tokenization.get(thisTokenIndex)) == '(' && cf.tokenization.get(thisTokenIndex)+1 == cf.tokenization.get(thisTokenIndex + 1);
                if(! matches)
                {
                    foundMatch = false;
                    break;
                }
            }
            if(foundMatch)
            {
                int startTokenIndexOfMethodName = i + 2;
                int endTokenIndexOfMethodName = i + 3;
                String functionName = cf.text.substring(cf.tokenization.get(startTokenIndexOfMethodName), cf.tokenization.get(endTokenIndexOfMethodName));
                cf.functionLocations.put(functionName, i + 2);
                cf.functionFiles.put(functionName, cf);
            }
        }
    }
    public static Tuple<CodeFile, Integer> searchForFunction(CodeFile startSearchFile, String functionName)
    {
        if(startSearchFile.functionFiles.keySet().contains(functionName))
        {
            CodeFile file = startSearchFile.functionFiles.get(functionName);
            int tokenIndex = file.functionLocations.get(functionName);
            return new Tuple<>(file, tokenIndex);
        }
        Directory doNotSearch = null;
        Directory currentDir = startSearchFile.parent;
        
        while(true)
        {
            if(currentDir == null) return null;
            Tuple<CodeFile, Integer> searchResult = breadthFirstSearchForFunction(currentDir, functionName, doNotSearch);
            if(searchResult != null) return searchResult;
            doNotSearch = currentDir;
            currentDir = currentDir.parent;
            
        }
    }
    
    /*
    Directory doNotSearch should either be null, or it should be a Directory that is 
    directly a child of the Directory startSearch.
    */
    @SuppressWarnings("unchecked")
    public static Tuple<CodeFile, Integer> breadthFirstSearchForFunction(Directory startSearch, String functionName, Directory doNotSearch)
    {
        for(CodeFile f : startSearch.files)
        {
            if(f.functionFiles.keySet().contains(functionName))
            {
                CodeFile file = f.functionFiles.get(functionName);
                int tokenIndex = file.functionLocations.get(functionName);
                return new Tuple<>(file, tokenIndex);
            }
        }
        ArrayList<Directory> subdirs = (ArrayList<Directory>)startSearch.subdirs.clone();
        
        subdirs.remove(doNotSearch);
        
        while(true)
        {
            for(Directory subdir : subdirs)
            {
                for(CodeFile f : subdir.files)
                {
                    if(f.functionFiles.keySet().contains(functionName))
                    {
                        CodeFile file = f.functionFiles.get(functionName);
                        int tokenIndex = file.functionLocations.get(functionName);
                        return new Tuple<>(file, tokenIndex);
                    }
                }
            }
            ArrayList<Directory> newSubdirs = new ArrayList<>();
            for(Directory subdir : subdirs)
            {
                for(Directory subSubdir : subdir.subdirs)
                {
                    newSubdirs.add(subSubdir);
                }
            }
            subdirs = newSubdirs;
            if(subdirs.isEmpty())
                return null;
        }
    }
    /*
    Calculates the indent of the line on which the token at index "index" resides.
    
    If the indent is n spaces, then this method returns n/4.
    
    */
    public static int getIndent(int index, ArrayList<Integer> tokenization, String text)
    {
        for(int i = index; i >= 0; i-=2)
        {
            if(getTokenTypeNoErr(i, tokenization, text) == TOKEN_TYPE_INDENT)
            {
                int start = tokenization.get(i);
                int end = tokenization.get(i + 1);
                return (end - start - 1)/4;
            }
        }
        return 0;
        
    }
    public static int getTokenTypeNoErr(int index, ArrayList<Integer> tokenization, String text)
    {
        if(index < 0 || index >= tokenization.size())
        {
            return -1;
        }
        return getTokenType(index, tokenization, text);
    }
    public static int getTokenType(int index, ArrayList<Integer> tokenization, String text)
    {
        if(index > tokenization.size())
            throw new RuntimeException(index + ", which is the index requested is greater than the size of tokenization array. How could you do this?");
        if(index % 2 == 1)
            throw new RuntimeException(index + ", which is the index requested is not even, which means something is screwed up here.");
        int start = tokenization.get(index);
        int end = tokenization.get(index+1);
        
        if(start == end)
            throw new RuntimeException("This token, at index " + index + " of the tokenization array, has a length of 0. What the hack?");
        int tokenType;
        char startChar = text.charAt(start);
        if(Character.isLetter(startChar) || startChar == '_')
            tokenType = TOKEN_TYPE_WORDNUM;
        else if(Character.isDigit(startChar))
        {
            boolean isInteger = true;
            for(int z = i; z < text.length(); z++)
            {
                if(!Character.isDigit(text.charAt(z)))
                {
                    if(text.charAt(z) == '.')
                    {
                        isInteger = false;
                        break;
                    }
                    else
                        break;
                }
            }
            if(isInteger)tokenType = TOKEN_TYPE_INTEGER_LITERAL;
            else tokenType = TOKEN_TYPE_DOUBLE_LITERAL;
        }
        else if(startChar == '\n')
            tokenType = TOKEN_TYPE_INDENT;
        else if(startChar == '-' && start+1 < text.length() && text.charAt(start+1) == '-')
            tokenType = TOKEN_TYPE_COMMENT;
        else if(startChar == '"')
            tokenType = TOKEN_TYPE_STRING_LITERAL
        else
            tokenType = TOKEN_TYPE_PUNC;
        return tokenType;
    }
    
    public static ArrayList<Integer> tokenize(String text)
    {
        ArrayList<Integer> ret = new ArrayList<>();
        //tokenization
        int textLength = text.length();
        int i = 0;
        //p(textLength);
        outerLoop:
        while(true)
        {
            
            while(true)//find start of token
            {
                if(i >= textLength) break outerLoop;
                if(text.charAt(i) != ' ')//found the start
                    break;
                i++;
            }
            
            //find the token type
            int tokenType;
            char charHere = text.charAt(i);
            if(Character.isLetter(charHere) || charHere == '_')
                tokenType = TOKEN_TYPE_IDENTIFIER;
            else if(Character.isDigit(charHere))
            {
                boolean isInteger = true;
                for(int z = i; z < text.length(); z++)
                {
                    if(!Character.isDigit(text.charAt(z)))
                    {
                        if(text.charAt(z) == '.')
                        {
                            isInteger = false;
                            break;
                        }
                        else
                            break;
                    }
                }
                if(isInteger)tokenType = TOKEN_TYPE_INTEGER_LITERAL;
                else tokenType = TOKEN_TYPE_DOUBLE_LITERAL;
            }
            else if(charHere == '\n')
                tokenType = TOKEN_TYPE_INDENT;
            else if(charHere == '-' && i+1 < textLength && text.charAt(i+1) == '-')
                tokenType = TOKEN_TYPE_COMMENT;
            else if(charHere == '"')
                tokenType = TOKEN_TYPE_STRING_LITERAL
            else
                tokenType = TOKEN_TYPE_PUNC;
            int j = i;
            
            
            switch(tokenType)//find the end of token
            {
                case 1:
                    
                    while(j < textLength)
                    {
                        if(!Character.isLetterOrDigit(text.charAt(j)) && (text.charAt(j) != '_'))
                        {
                            break;
                        }
                        j++;
                    }
                    break;
                case 2:
                    j = i + 1;
                    break;
                case 3:
                    j = i + 1;
                    while(j < textLength)
                    {
                        if(text.charAt(j) != ' ')
                        {
                            break;
                        }
                        j++;
                    }
                    break;
                case 4:
                    int numConsecDash = 0;
                    while(j < textLength)//find the number consecutive dashes at the comment start
                    {
                        if(text.charAt(j) == '-')
                        {
                            numConsecDash++;
                            j++;
                        }
                        else
                        {
                            break;
                        }
                    }
                    int closeNumConsecDash = 0;
                    while(j < textLength)//see if we can find a sequence of consecutive dashes that can close out this comment
                    {
                        if(text.charAt(j) == '-')
                            closeNumConsecDash++;
                        else
                            closeNumConsecDash = 0;
                        
                        
                        j++;
                        if(closeNumConsecDash == numConsecDash)
                        {
                            break;
                        }
                    }
                    break;
                case 5:
                    while(j < textLength)
                    {
                        if(!Character.isDigit(text.charAt(j)))
                            break;
                        j++;
                    }
                    break;
                case 6:
                    while(j < textLength)
                    {
                        if(!Character.isDigit(text.charAt(j)) && ! Character.isDigit(text.charAt(j)))
                            break;
                        j++;
                    }
                    break;
                case 7:
                    while(j < textLength)
                    {
                        if(text.charAt(j) == '"')
                        {
                            j++;
                            break;
                        }
                        j++;
                    }
                    break;
            }
            //p("adding token " + i + " , " + j);
            if(tokenType != TOKEN_TYPE_COMMENT)
            {
                ret.add(i);
                ret.add(j);
            }
            i = j;
        }
        return ret;
    }
    public static String efficientLoadFile(String filePath)
    {
        String fileName = filePath;
        try
        {
            FileInputStream fis = new FileInputStream(fileName);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while((line = br.readLine()) != null)
                sb.append(line+"\n");
            br.close();
            return sb.toString();
        }
        catch(Exception e){error("There was a problem loading the file \"" + filePath + "\"." );return null;}
    }
    public static void require(boolean requirement, String errorMessage)
    {
        if(!requirement)
        {
            error(errorMessage);
        }
    }
    public static void error(String errorMessage)
    {
        p(errorMessage);
        stop();
    }
    public static boolean portionEquals(int tokenIndex, ArrayList<Integer> tokenization, String body, String compare)
    {
        int start = tokenization.get(tokenIndex);
        int end = tokenization.get(tokenIndex+1);
        int len = end - start;
        
        if(len != compare.length()) return false;
        
        for(int i = 0; i < len; i++)
        {
            if(body.charAt(i + start) != compare.charAt(i))
            {
                return false;
            }
        }
        return true;
    }
}

    /*
    
    
    public static void doTokenization(CodeFile codeFile)
    {
        //tokenization
        int textLength = codeFile.text.length();
        int i = 0;
        //p(textLength);
        outerLoop:
        while(true)
        {
            
            while(true)//find start of token
            {
                if(i >= textLength) break outerLoop;
                if(codeFile.text.charAt(i) != ' ')//found the start
                    break;
                i++;
            }
            
            //find the token type
            int tokenType;
            char charHere = codeFile.text.charAt(i);
            if(Character.isLetterOrDigit(charHere) || charHere == '_')
                tokenType = TOKEN_TYPE_WORDNUM;
            else if(charHere == '\n')
                tokenType = TOKEN_TYPE_INDENT;
            else if(charHere == '-' && i+1 < textLength && codeFile.text.charAt(i+1) == '-')
                tokenType = TOKEN_TYPE_COMMENT;
            else
                tokenType = TOKEN_TYPE_PUNC;
            int j = i;
            
            
            switch(tokenType)//find the end of token
            {
                case 1:
                    
                    while(j < textLength)
                    {
                        if(!Character.isLetterOrDigit(codeFile.text.charAt(j)) && (codeFile.text.charAt(j) != '_'))
                        {
                            break;
                        }
                        j++;
                    }
                    break;
                case 2:
                    j = i + 1;
                    break;
                case 3:
                    j = i + 1;
                    while(j < textLength)
                    {
                        if(codeFile.text.charAt(j) != ' ')
                        {
                            break;
                        }
                        j++;
                    }
                    break;
                case 4:
                    int numConsecDash = 0;
                    while(j < textLength)//find the number consecutive dashes at the comment start
                    {
                        if(codeFile.text.charAt(j) == '-')
                        {
                            numConsecDash++;
                            j++;
                        }
                        else
                        {
                            break;
                        }
                    }
                    int closeNumConsecDash = 0;
                    while(j < textLength)//see if we can find a sequence of consecutive dashes that can close out this comment
                    {
                        if(codeFile.text.charAt(j) == '-')
                            closeNumConsecDash++;
                        else
                            closeNumConsecDash = 0;
                        
                        
                        j++;
                        if(closeNumConsecDash == numConsecDash)
                        {
                            break;
                        }
                    }
                    break;
            }
            //p("adding token " + i + " , " + j);
            codeFile.tokenization.add(i);
            codeFile.tokenization.add(j);
            i = j;
        }
    }*/