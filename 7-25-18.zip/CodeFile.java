import java.util.ArrayList;
import java.util.HashMap;
import java.io.File;
import static ljs.Obj.*;
public class CodeFile
{
    public Directory parent;
    public File myFile;
    public String text;
    public ArrayList<Integer> tokenization;
    
    //what file is this function in?
    //gets updated with the lazy evaluation
    public HashMap<String, CodeFile> functionFiles = new HashMap<>(); 
    
    
    public HashMap<String, Integer> functionLocations = new HashMap<>(); //what position in the tokenization is this function at?//only contains information for functions that are actually in this file
    public HashMap<String, ArrayList<FunctionModifier>> functionBeforeModifiers = new HashMap<>();//ordered and executed big to small
    public HashMap<String, ArrayList<FunctionModifier>> functionAfterModifiers = new HashMap<>();//ordered and executed small to big
    
    public String toString()
    {
        return myFile.getName() + ": tokenization-" + "..." + printTokenization() + " method locations: " + functionLocations + " function files: " + printFunctionFiles() + " functionModifiers: " + printFunctionModifiers();
    }
    public String printTokenization()
    {
        String ret = "";
        for(int i = 0; i < tokenization.size(); i+=2)
        {
            ret += "\"" + text.substring(tokenization.get(i), tokenization.get(i+1)) + "\" ";
        }
        return ret.replace("\n", "\\n");
    }
    public String printFunctionFiles()
    {
        String ret = "";
        for(String funcName : functionFiles.keySet())
        {
            ret += funcName + ":" + functionFiles.get(funcName).myFile.getName() + ", ";
        }
        return ret;
    }
    public String printFunctionModifiers()
    {
        String ret = "";
        ret += "functionBeforeModifiers: " ;
        for(String key : functionBeforeModifiers.keySet())
        {
            ret += key + ":" + functionBeforeModifiers.get(key) + " ";
        }
        ret += "...functionAfterModifiers: " ;
        for(String key : functionAfterModifiers.keySet())
        {
            ret += key + ":" + functionAfterModifiers.get(key) + " ";
        }
        return ret;
    }
}
