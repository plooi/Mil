import java.util.ArrayList;
import java.io.File;

public class Directory
{
    public Directory parent;
    public File myFile;
    public ArrayList<CodeFile> files = new ArrayList<>();
    public ArrayList<Directory> subdirs = new ArrayList<>();
    public String toString()
    {
        String ret = "";
        ret += "Directory of " + myFile.getName() + "\n";
        if(parent != null)
            ret += "Parent: " + parent.myFile.getName() + "\n";
        else
            ret += "Parent: null\n";
        ret += "Files: \n" ;
        for(CodeFile cf : files)
        {
            ret += cf.toString() + "\n";
        }
        ret += "Subdirectories: \n" ;
        for(Directory d : subdirs)
        {
            ret += d.toString() + "\n";
        }
        ret += "End directory of " + myFile.getName() + "\n";
        return ret;
    }
}
