public class FunctionModifier
{
    public CodeFile fileOfOrigin;//what file was this modifier written in?
    public int location;//what token index is this at
    public double order;
    public boolean tfBeforeAfter;
    public String toString()
    {
        return "FunctionModifier from file " + fileOfOrigin.myFile.getName() + " of priority " + order;
    }
}
